.. Birth-Death Langevin Dynamics documentation master file, created by
   sphinx-quickstart on Tue Jan 19 13:43:01 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Birth-Death augmented Langevin Dynamics
*****************************

.. toctree::

  install
  usage
  input
  developer
  changelog


This python package provides a simple Langevin Dynamics simulation with additional birth-death processes



Indices
*******

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
