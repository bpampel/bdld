"""Call the main function when module is executed (e.g. with `python -m bdld`)"""
from bdld import main

if __name__ == "__main__":
    main.main()
